class Item{
	String description;
	int unitPrice;
	
	Item(String desc,int unitPrice){
		description=desc;
		this.unitPrice=unitPrice;
	}
}

class bascket{
	Item itm[5];
	
	void addItem(Item i){
		
	}
	
	void calculatePrice(){
	
	};
}

class ShopDEMO{
	public static void main(String[] arg){
		Bascket basket1=new Bascket();
		char input='y';
	do{
		
		String desc=sc.nextLine();
		int up=sc.nextInt();
		itemList[i]=(desc);
		i++;
		
		
		}
	} 
}
